Descomprime el Archivo Zip en la carpeta htdocs de xampp.
La base de datos se importa a xampp, es el archivo llamado negocio_fotografia.sql
ingresa a tu navegador la ruta http://localhost/proyecto_ingenieria/pantallas/P_Menu_principal.php para acceder a la pagina principal.